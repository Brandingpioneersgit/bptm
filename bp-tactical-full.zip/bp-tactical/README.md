# Branding Pioneers – Monthly Tactical (MVP)

Vite + React + Tailwind app.

## Local
```bash
npm i
npm run dev
```

## Env (set in Netlify)
- VITE_SUPABASE_URL
- VITE_SUPABASE_ANON_KEY
- VITE_ADMIN_ACCESS_TOKEN (optional gate for #admin)

Manager dashboard URL: `/#admin`

## Supabase schema (run once)
```sql
create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(),
  month_key text not null,
  employee_email text not null,
  employee_name text not null,
  department text not null,
  role text not null,
  payload jsonb not null,
  scores jsonb not null,
  flags  jsonb not null,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
alter table public.submissions enable row level security;
create policy "public can insert submissions" on public.submissions for insert to anon with check (true);
create policy "read submissions (MVP)" on public.submissions for select to anon using (true);
```
